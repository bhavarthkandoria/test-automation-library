from setuptools import setup, find_packages

setup(
    name='hello_world',
    version='0.2',
    packages=find_packages(),
    install_requires=[],  # Add any dependencies here
)