def say_hello():
    print("Hello, World!, This is new version")