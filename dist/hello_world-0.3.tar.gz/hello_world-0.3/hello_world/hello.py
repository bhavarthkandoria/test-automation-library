def say_hello(name="Ram"):
    print("Hello, "+str(name)+"!, This is new version")